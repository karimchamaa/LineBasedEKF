% Add Matlab paths
fileDir = pwd;
paths = genpath([fileDir, '/..']);
addpath( paths );
clear fileDir paths
